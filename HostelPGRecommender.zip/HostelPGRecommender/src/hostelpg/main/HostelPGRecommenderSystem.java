package hostelpg.main;

import java.util.ArrayList;
import java.util.Scanner;

import hostelpg.hostels.Hostel;
import hostelpg.hostels.HostelManager;
import hostelpg.recommendations.RecommendationEngine;
import hostelpg.users.User;

public class HostelPGRecommenderSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("🏡 Welcome to Hostel/PG Recommender System 🏡");

        // --- Name Validation ---
        String name = "";
        while (true) {
            System.out.print("Enter your Name: ");
            name = sc.nextLine().trim();
            if (name.matches("[a-zA-Z ]+")) { // only letters and spaces
                break;
            } else {
                System.out.println("❌ Invalid input! Please enter a valid name (letters only).");
            }
        }

        // --- Age Validation ---
        int age = 0;
        while (true) {
            System.out.print("Enter your Age: ");
            try {
                age = Integer.parseInt(sc.nextLine().trim());
                if (age > 0) break;
                else System.out.println("❌ Invalid input! Age must be positive.");
            } catch (NumberFormatException e) {
                System.out.println("❌ Invalid input! Please enter a valid number.");
            }
        }

        // --- Gender Validation ---
        String gender = "";
        while (true) {
            System.out.print("Enter your Gender (M/F): ");
            gender = sc.nextLine().trim().toUpperCase();
            if (gender.equals("M") || gender.equals("F")) break;
            System.out.println("❌ Invalid input! Please enter M or F.");
        }

        // --- College Input ---
        System.out.print("Enter your College: ");
        String college = sc.nextLine();

        // --- Budget Validation ---
        double budget = 0;
        while (true) {
            System.out.print("Enter your Total Budget (Hostel + Mess): ");
            try {
                budget = Double.parseDouble(sc.nextLine().trim());
                if (budget >= 0) break;
                else System.out.println("❌ Invalid input! Budget must be non-negative.");
            } catch (NumberFormatException e) {
                System.out.println("❌ Invalid input! Please enter a valid number.");
            }
        }

        // --- AC Input Validation ---
        boolean wantsAc = false;
        while (true) {
            System.out.print("Do you want AC room? (true/false or T/F): ");
            String acInput = sc.nextLine().trim().toUpperCase();
            if (acInput.equals("TRUE") || acInput.equals("T")) {
                wantsAc = true;
                break;
            } else if (acInput.equals("FALSE") || acInput.equals("F")) {
                wantsAc = false;
                break;
            } else {
                System.out.println("❌ Invalid input! Please enter true/false or T/F.");
            }
        }

        // --- Sharing Preference Validation ---
        int sharing = 0;
        while (true) {
            System.out.print("Enter room sharing preference (1 / 3 / 5): ");
            try {
                sharing = Integer.parseInt(sc.nextLine().trim());
                if (sharing == 1 || sharing == 3 || sharing == 5) break;
                else System.out.println("❌ Invalid input! Please enter 1, 3, or 5.");
            } catch (NumberFormatException e) {
                System.out.println("❌ Invalid input! Please enter 1, 3, or 5.");
            }
        }

        // --- Create User ---
        User user = new User(name, age, gender, college, budget, wantsAc, sharing);
        System.out.println("\n✅ Your details recorded:\n" + user);

        // --- Add Hostels ---
        HostelManager hm = new HostelManager();
        hm.addHostel(new Hostel("H1", "Sunrise PG", "Near " + college, 4000, 1000, true, 1, true, 1.0, 4.5));
        hm.addHostel(new Hostel("H2", "Green Nest", "Near " + college, 2500, 1000, false, 3, true, 2.0, 4.0));
        hm.addHostel(new Hostel("H3", "Comfort Stay", "Near " + college, 2000, 800, false, 5, true, 4.0, 3.9));
        hm.addHostel(new Hostel("H4", "Elite Rooms", "Near " + college, 6000, 1500, true, 1, true, 3.0, 4.8));
        hm.addHostel(new Hostel("H5", "Cozy Corner", "Near " + college, 3500, 900, true, 3, true, 1.5, 4.2));
        hm.addHostel(new Hostel("H6", "Budget Stay", "Near " + college, 1800, 700, false, 5, false, 4.5, 3.5));
        hm.addHostel(new Hostel("H7", "Luxury Suites", "Near " + college, 7000, 2000, true, 1, true, 2.0, 4.9));
        hm.addHostel(new Hostel("H8", "Happy Hostel", "Near " + college, 2200, 800, false, 3, true, 3.5, 4.0));
        hm.addHostel(new Hostel("H9", "City Nest", "Near " + college, 3000, 1200, true, 1, false, 2.5, 4.3));

        // --- Recommend Hostels ---
        ArrayList<Hostel> recommended = RecommendationEngine.recommendHostels(user, hm.getHostels());

        System.out.println("\n✨ Recommended Hostels for You:");
        if (recommended.isEmpty()) {
            System.out.println("❌ No hostels match your preferences.");
        } else {
            for (Hostel h : recommended) {
                System.out.println(h);
            }
        }

        sc.close();
    }
}

