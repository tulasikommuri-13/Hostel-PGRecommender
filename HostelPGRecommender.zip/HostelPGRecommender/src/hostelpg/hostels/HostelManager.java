package hostelpg.hostels;

import java.util.ArrayList;

public class HostelManager {
    private ArrayList<Hostel> hostels = new ArrayList<>();

    public void addHostel(Hostel hostel) {
        hostels.add(hostel);
    }

    public ArrayList<Hostel> getHostels() {
        return hostels;
    }

    public void displayAllHostels() {
        System.out.println("\n🏨 All Available Hostels:");
        for (Hostel h : hostels) {
            System.out.println(h);
        }
    }
}
