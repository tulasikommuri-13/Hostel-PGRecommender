package hostelpg.hostels;

public class Hostel {
    private String hostelId;
    private String name;
    private String location;
    private double hostelFee;
    private double messFee;
    private boolean acAvailable;
    private int sharing;  // 1, 3, 5
    private boolean foodAvailable;
    private double distance; // from college in km
    private double rating;

    public Hostel(String hostelId, String name, String location,
                  double hostelFee, double messFee,
                  boolean acAvailable, int sharing,
                  boolean foodAvailable, double distance, double rating) {
        this.hostelId = hostelId;
        this.name = name;
        this.location = location;
        this.hostelFee = hostelFee;
        this.messFee = messFee;
        this.acAvailable = acAvailable;
        this.sharing = sharing;
        this.foodAvailable = foodAvailable;
        this.distance = distance;
        this.rating = rating;
    }

    public String getHostelId() { return hostelId; }
    public String getName() { return name; }
    public String getLocation() { return location; }
    public double getHostelFee() { return hostelFee; }
    public double getMessFee() { return messFee; }
    public boolean isAcAvailable() { return acAvailable; }
    public int getSharing() { return sharing; }
    public boolean isFoodAvailable() { return foodAvailable; }
    public double getDistance() { return distance; }
    public double getRating() { return rating; }

    public double getTotalCost() {
        return hostelFee + messFee;
    }

    @Override
    public String toString() {
        return hostelId + " | " + name + " | " + location +
               " | Total ₹" + getTotalCost() +
               " | AC: " + (acAvailable ? "Yes" : "No") +
               " | Sharing: " + sharing +
               " | Mess: " + (foodAvailable ? "Yes" : "No") +
               " | " + distance + "km | Rating: " + rating;
    }
}
