package hostelpg.recommendations;

import hostelpg.hostels.Hostel;
import hostelpg.users.User;
import java.util.ArrayList;

public class RecommendationEngine {
    public static ArrayList<Hostel> recommendHostels(User user, ArrayList<Hostel> hostels) {
        ArrayList<Hostel> recommended = new ArrayList<>();
        for (Hostel h : hostels) {
            if (h.getTotalCost() <= user.getBudget() &&
                h.isAcAvailable() == user.isWantsAc() &&
                h.getSharing() == user.getSharing() &&
                h.getDistance() <= 5.0) {  // near college
                recommended.add(h);
            }
        }
        return recommended;
    }
}
