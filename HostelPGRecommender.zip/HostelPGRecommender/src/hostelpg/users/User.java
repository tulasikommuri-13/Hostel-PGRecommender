package hostelpg.users;

public class User {
    private String name;
    private int age;
    private String gender;
    private String college;
    private double budget;
    private boolean wantsAc;
    private int sharing;

    public User(String name, int age, String gender, String college,
                double budget, boolean wantsAc, int sharing) {
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.college = college;
        this.budget = budget;
        this.wantsAc = wantsAc;
        this.sharing = sharing;
    }

    public double getBudget() { return budget; }
    public boolean isWantsAc() { return wantsAc; }
    public int getSharing() { return sharing; }
    public String getCollege() { return college; }

    @Override
    public String toString() {
        return "User: " + name + " | Age: " + age + " | " + gender +
               " | College: " + college +
               " | Budget: ₹" + budget +
               " | AC: " + (wantsAc ? "Yes" : "No") +
               " | Sharing: " + sharing;
    }
}
